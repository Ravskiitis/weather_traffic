// Stylized Bergen map. Coordinates are roughly geographic (not exact).
// Fjords (water), land masses, and road network drawn as SVG.

const BergenMap = ({ incidents = [], onPinHover, hoveredPinId }) => {
  return (
    <div className="bm-wrap">
      <svg viewBox="0 0 800 480" className="bm-svg" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="bm-water-hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="6" stroke="#DCE7F0" strokeWidth="1" />
          </pattern>
          <linearGradient id="bm-water" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#E8F0F6" />
            <stop offset="100%" stopColor="#DCE7F0" />
          </linearGradient>
          <linearGradient id="bm-land" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#F4F1EB" />
            <stop offset="100%" stopColor="#ECE6DA" />
          </linearGradient>
          <filter id="bm-pin-shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodOpacity="0.25" />
          </filter>
        </defs>

        {/* Water base */}
        <rect width="800" height="480" fill="url(#bm-water)" />
        <rect width="800" height="480" fill="url(#bm-water-hatch)" opacity="0.5" />

        {/* Land masses — Bergen peninsula + surrounding islands */}
        <g fill="url(#bm-land)" stroke="#D8D2C2" strokeWidth="1">
          {/* Askøy island (west) */}
          <path d="M 50,90 C 30,130 25,180 40,220 C 55,255 95,275 140,265 C 175,257 195,230 200,195 C 205,160 195,125 165,100 C 130,75 85,75 50,90 Z" />
          {/* Sotra (south-west) */}
          <path d="M 30,310 C 20,345 35,395 75,420 C 125,445 175,440 215,415 C 245,395 250,365 230,335 C 210,310 175,295 135,300 C 95,302 55,300 30,310 Z" />
          {/* Bergen mainland — main blob */}
          <path d="M 230,80 C 280,70 340,75 395,90 C 455,108 510,135 555,170 C 600,210 625,260 620,310 C 615,360 580,400 530,420 C 475,440 410,438 355,420 C 305,405 265,380 240,345 C 220,315 215,275 220,235 C 222,200 220,160 225,130 C 226,108 226,93 230,80 Z" />
          {/* Northern peninsula nub (Åsane) */}
          <path d="M 380,40 C 420,30 470,32 500,50 C 525,68 530,90 510,108 C 480,128 440,128 410,118 C 385,108 370,90 372,68 C 374,55 376,46 380,40 Z" />
          {/* Eastern hills (Arna) */}
          <path d="M 660,180 C 700,170 740,180 760,210 C 775,240 770,280 740,310 C 705,340 665,345 635,325 C 615,310 610,280 620,250 C 628,222 640,195 660,180 Z" />
          {/* Small island in fjord (Holmen) */}
          <ellipse cx="320" cy="215" rx="14" ry="8" />
          <ellipse cx="270" cy="280" rx="10" ry="6" />
          <ellipse cx="170" cy="155" rx="8" ry="5" />
        </g>

        {/* Inner fjord cutout — Byfjorden / Vågen — make water reach into the city */}
        <g fill="url(#bm-water)" stroke="#D8D2C2" strokeWidth="0.5">
          {/* Vågen harbor inlet */}
          <path d="M 295,205 C 320,200 345,205 360,220 C 370,232 365,245 350,250 C 330,255 305,250 295,235 C 288,225 288,212 295,205 Z" fill="url(#bm-water)" />
          {/* Puddefjorden cut */}
          <path d="M 230,250 C 260,245 285,255 295,275 C 300,290 285,300 260,300 C 235,298 215,285 220,268 C 222,260 226,253 230,250 Z" />
        </g>

        {/* Mountains (subtle) */}
        <g fill="#E5DDC9" opacity="0.6">
          <path d="M 410,140 l 20,-30 l 20,30 z" />
          <path d="M 460,160 l 18,-24 l 18,24 z" />
          <path d="M 380,200 l 16,-20 l 16,20 z" />
          <path d="M 500,260 l 22,-32 l 22,32 z" />
          <path d="M 540,200 l 18,-26 l 18,26 z" />
        </g>
        <g fill="none" stroke="#C9C0AB" strokeWidth="0.8">
          <path d="M 410,140 l 20,-30 l 20,30" />
          <path d="M 460,160 l 18,-24 l 18,24" />
          <path d="M 500,260 l 22,-32 l 22,32" />
        </g>

        {/* Road network — major motorways + tunnels */}
        {/* E39 (north-south corridor) */}
        <g fill="none" strokeLinecap="round" strokeLinejoin="round">
          {/* E39 casing */}
          <path d="M 440,50 C 430,90 410,135 395,180 C 380,220 365,270 360,320 C 358,360 370,395 395,420"
                stroke="#C8A86A" strokeWidth="6" opacity="0.4" />
          <path d="M 440,50 C 430,90 410,135 395,180 C 380,220 365,270 360,320 C 358,360 370,395 395,420"
                stroke="#E8C778" strokeWidth="3.5" />

          {/* E16 east toward Arna (with tunnel — Fløyfjelltunnelen / Arnatunnelen) */}
          <path d="M 360,235 L 410,240 L 470,245 L 540,250 L 610,260" stroke="#C8A86A" strokeWidth="5.5" opacity="0.4" />
          <path d="M 360,235 L 410,240 L 470,245 L 540,250 L 610,260" stroke="#E8C778" strokeWidth="3" />
          {/* Tunnel dashed segment */}
          <path d="M 410,240 L 540,250" stroke="#FFFFFF" strokeWidth="1.5" strokeDasharray="4 3" />

          {/* Rv580 — south toward airport */}
          <path d="M 360,260 C 365,310 360,360 350,400" stroke="#B8B0A0" strokeWidth="4" opacity="0.5" />
          <path d="M 360,260 C 365,310 360,360 350,400" stroke="#D8D0BE" strokeWidth="2.2" />

          {/* Puddefjordsbroen (bridge) */}
          <path d="M 235,270 L 295,275" stroke="#B8B0A0" strokeWidth="4" opacity="0.5" />
          <path d="M 235,270 L 295,275" stroke="#D8D0BE" strokeWidth="2.2" />

          {/* Fv585 — local routes */}
          <path d="M 320,180 C 360,170 400,165 450,170" stroke="#B8B0A0" strokeWidth="3" opacity="0.4" />
          <path d="M 320,180 C 360,170 400,165 450,170" stroke="#D8D0BE" strokeWidth="1.8" />

          {/* Rv555 to Sotra */}
          <path d="M 300,300 C 260,330 220,350 180,360" stroke="#B8B0A0" strokeWidth="3.5" opacity="0.4" />
          <path d="M 300,300 C 260,330 220,350 180,360" stroke="#D8D0BE" strokeWidth="2" />
        </g>

        {/* Road labels */}
        <g fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#7A6E55" fontWeight="600">
          <text x="445" y="55" textAnchor="middle">
            <tspan fill="#FFFFFF" stroke="#7A6E55" strokeWidth="3" paintOrder="stroke">E39</tspan>
          </text>
          <text x="618" y="265">
            <tspan fill="#FFFFFF" stroke="#7A6E55" strokeWidth="3" paintOrder="stroke">E16</tspan>
          </text>
          <text x="345" y="395">
            <tspan fill="#FFFFFF" stroke="#7A6E55" strokeWidth="3" paintOrder="stroke">Rv580</tspan>
          </text>
          <text x="170" y="370">
            <tspan fill="#FFFFFF" stroke="#7A6E55" strokeWidth="3" paintOrder="stroke">Rv555</tspan>
          </text>
        </g>

        {/* Place labels */}
        <g fontFamily="Inter, sans-serif" fontSize="10" fill="#475569">
          <text x="120" y="180" textAnchor="middle" fontWeight="500">Askøy</text>
          <text x="125" y="370" textAnchor="middle" fontWeight="500">Sotra</text>
          <text x="445" y="78" textAnchor="middle" fontWeight="600" fill="#0F172A">Åsane</text>
          <text x="380" y="245" textAnchor="middle" fontWeight="700" fill="#0F172A" fontSize="12">Bergen sentrum</text>
          <text x="700" y="255" textAnchor="middle" fontWeight="500">Arna</text>
          <text x="320" y="330" textAnchor="middle" fontWeight="500" fill="#475569">Fyllingsdalen</text>
        </g>

        {/* Compass */}
        <g transform="translate(750,40)">
          <circle r="14" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="1" />
          <path d="M 0,-9 L 3,2 L 0,0 L -3,2 Z" fill="#E85D2C" />
          <path d="M 0,9 L 3,-2 L 0,0 L -3,-2 Z" fill="#94A3B8" />
          <text y="-16" textAnchor="middle" fontSize="8" fontFamily="Inter" fontWeight="700" fill="#475569">N</text>
        </g>

        {/* Scale bar */}
        <g transform="translate(40,440)" fontFamily="JetBrains Mono, monospace" fontSize="9" fill="#475569">
          <line x1="0" y1="0" x2="60" y2="0" stroke="#475569" strokeWidth="1.5" />
          <line x1="0" y1="-3" x2="0" y2="3" stroke="#475569" strokeWidth="1.5" />
          <line x1="30" y1="-3" x2="30" y2="3" stroke="#475569" strokeWidth="1" />
          <line x1="60" y1="-3" x2="60" y2="3" stroke="#475569" strokeWidth="1.5" />
          <text x="0" y="14">0</text>
          <text x="60" y="14" textAnchor="middle">2 km</text>
        </g>

        {/* Pins */}
        {incidents.map((p) => {
          const color = p.kind === "incident" ? "#DC2626" : p.kind === "tunnel" ? "#E85D2C" : "#CA8A04";
          const isHover = hoveredPinId === p.id;
          return (
            <g
              key={p.id}
              transform={`translate(${p.x},${p.y})`}
              filter="url(#bm-pin-shadow)"
              onMouseEnter={() => onPinHover && onPinHover(p.id)}
              onMouseLeave={() => onPinHover && onPinHover(null)}
              style={{ cursor: "pointer" }}
            >
              {isHover && <circle r="14" fill={color} opacity="0.18" />}
              <circle r="9" fill="#FFFFFF" stroke={color} strokeWidth="2.5" />
              <circle r="3.5" fill={color} />
            </g>
          );
        })}

        {/* Hover tooltip */}
        {hoveredPinId && (() => {
          const p = incidents.find((i) => i.id === hoveredPinId);
          if (!p) return null;
          const tx = Math.min(p.x + 14, 580);
          const ty = Math.max(p.y - 50, 12);
          return (
            <g transform={`translate(${tx},${ty})`}>
              <rect width="200" height="44" rx="6" fill="#0F172A" />
              <text x="10" y="17" fill="#FFFFFF" fontSize="11" fontFamily="Inter" fontWeight="600">{p.title}</text>
              <text x="10" y="33" fill="#CBD5E1" fontSize="10" fontFamily="Inter">{p.subtitle}</text>
            </g>
          );
        })()}
      </svg>

      {/* Map controls */}
      <div className="bm-controls">
        <button className="bm-ctrl">+</button>
        <button className="bm-ctrl">−</button>
      </div>

      {/* Legend */}
      <div className="bm-legend">
        <div className="bm-legend-item"><span className="bm-dot" style={{ background: "#DC2626" }} />Active incident</div>
        <div className="bm-legend-item"><span className="bm-dot" style={{ background: "#E85D2C" }} />Closed tunnel</div>
        <div className="bm-legend-item"><span className="bm-dot" style={{ background: "#CA8A04" }} />Construction zone</div>
      </div>

      {/* Attribution */}
      <div className="bm-attr">© Statens vegvesen · MET Norway</div>
    </div>
  );
};

window.BergenMap = BergenMap;
