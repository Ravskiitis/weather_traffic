// Main weather_traffic dashboard app
const { useState, useMemo, useEffect } = React;

// ─── Mock data ───────────────────────────────────────────────────────────────

const MAP_PINS = [
  { id: "p1", x: 380, y: 220, kind: "incident", title: "E39 · Vehicle collision", subtitle: "Nordhordlandsbroen, southbound" },
  { id: "p2", x: 470, y: 248, kind: "tunnel", title: "Eikåstunnelen — closed", subtitle: "Flooding · since 06:42" },
  { id: "p3", x: 320, y: 200, kind: "incident", title: "Bryggen · Reduced flow", subtitle: "Surface water · 22% slower" },
  { id: "p4", x: 250, y: 282, kind: "incident", title: "Puddefjordsbroen", subtitle: "Strong crosswind warning" },
  { id: "p5", x: 540, y: 200, kind: "construction", title: "Fv585 · Roadworks", subtitle: "Lane closure 09:00–17:00" },
  { id: "p6", x: 360, y: 295, kind: "tunnel", title: "Damsgårdstunnelen", subtitle: "Reduced visibility · partial closure" },
  { id: "p7", x: 425, y: 170, kind: "construction", title: "E39 Åsane · Resurfacing", subtitle: "Ongoing through 18 May" },
];

const CHART_DATA = [
  { day: "Mon", date: "27 Apr", incidents: 3, precip: 4 },
  { day: "Tue", date: "28 Apr", incidents: 2, precip: 1 },
  { day: "Wed", date: "29 Apr", incidents: 5, precip: 12 },
  { day: "Thu", date: "30 Apr", incidents: 4, precip: 8 },
  { day: "Fri", date: "01 May", incidents: 7, precip: 18 },
  { day: "Sat", date: "02 May", incidents: 6, precip: 22 },
  { day: "Sun", date: "03 May", incidents: 8, precip: 26 },
];

const INCIDENTS = [
  {
    id: 1, location: "E39 Nordhordlandsbroen", route: "E39",
    type: "Collision", typeIcon: "car",
    severity: "High", started: "07:18", duration: "1h 32m",
    weather: "Heavy rain · 9.2 mm/h", weatherIcon: "rain",
    status: "Active",
  },
  {
    id: 2, location: "Eikåstunnelen", route: "E39",
    type: "Tunnel closure", typeIcon: "tunnel",
    severity: "High", started: "06:42", duration: "2h 08m",
    weather: "Flooding", weatherIcon: "rain",
    status: "Closed",
  },
  {
    id: 3, location: "Fløyfjelltunnelen", route: "E39",
    type: "Reduced visibility", typeIcon: "tunnel",
    severity: "Medium", started: "08:05", duration: "0h 45m",
    weather: "Fog · 200m visibility", weatherIcon: "cloud",
    status: "Active",
  },
  {
    id: 4, location: "Puddefjordsbroen", route: "Rv555",
    type: "Wind warning", typeIcon: "wind",
    severity: "Medium", started: "05:30", duration: "3h 20m",
    weather: "Gusts 22 m/s", weatherIcon: "wind",
    status: "Monitoring",
  },
  {
    id: 5, location: "Damsgårdstunnelen", route: "Rv555",
    type: "Partial closure", typeIcon: "tunnel",
    severity: "Low", started: "09:14", duration: "0h 24m",
    weather: "Light rain · 1.4 mm/h", weatherIcon: "rain",
    status: "Active",
  },
  {
    id: 6, location: "Fv585 Arna", route: "Fv585",
    type: "Roadworks", typeIcon: "construction",
    severity: "Low", started: "Mon 09:00", duration: "Scheduled",
    weather: "Overcast · 6°C", weatherIcon: "cloud",
    status: "Active",
  },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: "IconLayoutDashboard" },
  { id: "history", label: "History", icon: "IconHistory" },
  { id: "reports", label: "Reports", icon: "IconReports" },
  { id: "settings", label: "Settings", icon: "IconSettings" },
];

const TypeIcon = ({ kind, size = 14 }) => {
  switch (kind) {
    case "car": return <IconCar size={size} />;
    case "tunnel": return <IconTunnel size={size} />;
    case "wind": return <IconWind size={size} />;
    case "construction": return <IconConstruction size={size} />;
    case "rain": return <IconCloudRain size={size} />;
    case "cloud": return <IconCloud size={size} />;
    default: return null;
  }
};

const SeverityBadge = ({ level }) => {
  const map = {
    High: { bg: "#FEE2E2", fg: "#B91C1C", dot: "#DC2626" },
    Medium: { bg: "#FEF3C7", fg: "#92400E", dot: "#D97706" },
    Low: { bg: "#FEF9C3", fg: "#854D0E", dot: "#CA8A04" },
  };
  const c = map[level] || map.Low;
  return (
    <span className="sev-badge" style={{ background: c.bg, color: c.fg }}>
      <span className="sev-dot" style={{ background: c.dot }} />
      {level}
    </span>
  );
};

const StatusBadge = ({ status }) => {
  const map = {
    Active: { bg: "#FEF2F2", fg: "#B91C1C" },
    Closed: { bg: "#1E293B", fg: "#FFFFFF" },
    Monitoring: { bg: "#EFF6FF", fg: "#1D4ED8" },
    Resolved: { bg: "#F0FDF4", fg: "#15803D" },
  };
  const c = map[status] || map.Active;
  return <span className="status-badge" style={{ background: c.bg, color: c.fg }}>{status}</span>;
};

// ─── Sections ────────────────────────────────────────────────────────────────

const TopNav = ({ lang, setLang, activeTab, setActiveTab }) => (
  <header className="topnav">
    <div className="topnav-left">
      <div className="logo">
        <div className="logo-mark">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
            <path d="M4 16 L9 11 L13 14 L20 7" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="20" cy="7" r="2.5" fill="#FFFFFF" />
          </svg>
        </div>
        <div className="logo-text">
          <span className="logo-prefix">weather</span>
          <span className="logo-sep">_</span>
          <span className="logo-suffix">traffic</span>
        </div>
      </div>
    </div>

    <nav className="topnav-tabs">
      {NAV_ITEMS.map((item) => {
        const IconComp = window[item.icon];
        return (
          <button
            key={item.id}
            className={`tab ${activeTab === item.id ? "tab-active" : ""}`}
            onClick={() => setActiveTab(item.id)}
          >
            <IconComp size={16} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>

    <div className="topnav-right">
      <div className="lang-toggle">
        <button className={lang === "NO" ? "lang-on" : ""} onClick={() => setLang("NO")}>NO</button>
        <button className={lang === "EN" ? "lang-on" : ""} onClick={() => setLang("EN")}>EN</button>
      </div>
      <button className="icon-btn" title="Notifications">
        <IconBell size={18} />
        <span className="bell-dot" />
      </button>
      <div className="avatar">MB</div>
    </div>
  </header>
);

const PageHeader = ({ onGenerate, generating }) => (
  <div className="page-header">
    <div>
      <div className="breadcrumb">
        <span>Operations</span>
        <span className="bc-sep">/</span>
        <span>Bergen</span>
      </div>
      <h1 className="h1">Bergen — Traffic &amp; Weather Overview</h1>
      <div className="page-sub">
        <span className="ps-item"><IconCalendar size={13} /> Sunday, 3 May 2026 · 14:32 CEST</span>
        <span className="ps-dot" />
        <span className="ps-item ps-muted">Last refresh <span className="mono">2 min ago</span> · Sources: MET Norway, Statens vegvesen</span>
      </div>
    </div>
    <button className={`btn-primary ${generating ? "is-loading" : ""}`} onClick={onGenerate} disabled={generating}>
      <IconSparkle size={15} />
      {generating ? "Generating…" : "Generate fresh AI report"}
    </button>
  </div>
);

const KPITile = ({ label, value, unit, trend, trendLabel, icon, sub, riskLevel }) => (
  <div className="kpi">
    <div className="kpi-top">
      <span className="kpi-label">{label}</span>
      <span className="kpi-icon">{icon}</span>
    </div>
    <div className="kpi-value-row">
      <span className="kpi-value">{value}</span>
      {unit && <span className="kpi-unit">{unit}</span>}
    </div>
    <div className="kpi-bottom">
      {trend && (
        <span className={`kpi-trend kpi-trend-${trend}`}>
          {trend === "up" ? <IconArrowUp size={11} stroke={2.2} /> : <IconArrowDown size={11} stroke={2.2} />}
          {trendLabel}
        </span>
      )}
      {riskLevel && (
        <span className={`risk-pill risk-${riskLevel.toLowerCase()}`}>
          <span className="risk-dot" />
          {riskLevel} risk
        </span>
      )}
      {sub && <span className="kpi-sub">{sub}</span>}
    </div>
  </div>
);

const KPIRow = () => (
  <div className="kpi-row">
    <KPITile
      label="Active incidents"
      value="6"
      icon={<IconAlertTriangle size={16} />}
      trend="up"
      trendLabel="+2 vs yesterday"
    />
    <KPITile
      label="Closed tunnels"
      value="2"
      icon={<IconTunnel size={16} />}
      sub={<span><span className="mono">Eikås</span> · <span className="mono">Damsgård</span></span>}
    />
    <KPITile
      label="Current temperature"
      value="6.2"
      unit="°C"
      icon={<IconCloudRain size={16} />}
      sub={<span>Feels <span className="mono">3.8°C</span> · Bergen sentrum</span>}
    />
    <KPITile
      label="Precipitation 24h"
      value="38.4"
      unit="mm"
      icon={<IconDroplet size={16} />}
      riskLevel="High"
    />
  </div>
);

const AIReport = ({ generating }) => {
  const [showCursor, setShowCursor] = useState(false);
  useEffect(() => {
    if (generating) {
      setShowCursor(true);
      const t = setTimeout(() => setShowCursor(false), 2500);
      return () => clearTimeout(t);
    }
  }, [generating]);

  return (
    <section className="ai-card">
      <div className="ai-accent" />
      <div className="ai-bg-glow" />
      <div className="ai-header">
        <div className="ai-header-left">
          <div className="ai-icon-wrap">
            <IconSparkle size={16} />
          </div>
          <div>
            <div className="ai-title">
              AI Analysis
              <span className="ai-badge">
                <span className="ai-badge-dot" />
                Powered by Claude
              </span>
            </div>
            <div className="ai-meta">
              Generated <span className="mono">14 minutes ago</span> · Model: claude-sonnet-4-5 · Confidence <span className="mono">87%</span>
            </div>
          </div>
        </div>
        <div className="ai-tag">
          <span className="ai-tag-pulse" />
          Live correlation
        </div>
      </div>

      <div className="ai-body">
        <p>
          <strong>Heavy rainfall over the last 18 hours has correlated with 3 of 6 active incidents on the E39 corridor.</strong>{" "}
          MET Norway recorded <span className="mono">38.4 mm</span> of cumulative precipitation in Bergen sentrum since 20:00 yesterday — the wettest stretch of this week and the second-wettest May day on record at Florida station. Surface water on Bryggen is reducing southbound flow by approximately <span className="mono">22%</span> compared to the same Sunday last week.
          {showCursor && <span className="ai-cursor" />}
        </p>
        <p>
          The <strong>Eikåstunnelen</strong> remains closed since <span className="mono">06:42</span> due to flooding at the eastern portal; Statens vegvesen has rerouted heavy traffic via Fv585 through Arna, adding an estimated <span className="mono">14 minutes</span> to the typical Åsane → sentrum journey. Fløyfjelltunnelen is operational but visibility has dropped below 200 m intermittently — drivers should expect variable speed limits between <span className="mono">60</span> and <span className="mono">80 km/h</span>.
        </p>
        <p>
          A wind warning is in effect for <strong>Puddefjordsbroen</strong> through <span className="mono">15:00</span>, with sustained gusts of <span className="mono">22 m/s</span> from the south-west. Historical data suggests a <span className="mono">3.4×</span> increase in single-vehicle incidents on the bridge under these conditions; we recommend pausing dispatch of high-sided vehicles and notifying fleet drivers via SMS template <span className="mono">#FW-04</span>.
        </p>
        <p>
          <strong>Outlook:</strong> precipitation intensity should ease after <span className="mono">17:00</span> as the front moves north-east toward Voss. Tunnel reopening at Eikås is unlikely before <span className="mono">19:00</span>; expect residual surface-water incidents through the evening commute. We will re-run this analysis at the next data refresh in <span className="mono">28 minutes</span>.
        </p>
      </div>

      <div className="ai-footer">
        <div className="ai-citations">
          <span className="ai-cite">Sources:</span>
          <span className="ai-cite-pill">MET Norway · Locationforecast 2.0</span>
          <span className="ai-cite-pill">Vegvesen · Datex II</span>
          <span className="ai-cite-pill">Internal · 30-day baseline</span>
        </div>
        <div className="ai-actions">
          <button className="btn-ghost"><IconRefresh size={13} /> Regenerate</button>
          <button className="btn-ghost"><IconDownload size={13} /> Export PDF</button>
          <button className="btn-ghost"><IconShare size={13} /> Share</button>
        </div>
      </div>
    </section>
  );
};

const WeatherCard = () => {
  const next6h = [
    { h: "15", mm: 4.2 }, { h: "16", mm: 5.1 }, { h: "17", mm: 3.8 },
    { h: "18", mm: 2.1 }, { h: "19", mm: 0.9 }, { h: "20", mm: 0.3 },
  ];
  const maxMm = Math.max(...next6h.map((x) => x.mm));
  return (
    <div className="weather-card">
      <div className="wc-top">
        <div className="wc-loc">
          <div className="wc-loc-label">Bergen sentrum</div>
          <div className="wc-loc-sub">Florida weather station · 12 m.a.s.l.</div>
        </div>
        <div className="wc-condition">
          <IconCloudRain size={36} />
        </div>
      </div>

      <div className="wc-temp-row">
        <div className="wc-temp">
          <span className="wc-temp-num">6.2</span>
          <span className="wc-temp-unit">°C</span>
        </div>
        <div className="wc-cond-text">
          <div className="wc-cond-label">Heavy rain</div>
          <div className="wc-feels">Feels like <span className="mono">3.8°C</span></div>
        </div>
      </div>

      <div className="wc-stats">
        <div className="wc-stat">
          <div className="wc-stat-icon"><IconWind size={14} /></div>
          <div>
            <div className="wc-stat-label">Wind</div>
            <div className="wc-stat-value"><span className="mono">14</span> m/s SW</div>
          </div>
        </div>
        <div className="wc-stat">
          <div className="wc-stat-icon"><IconDroplet size={14} /></div>
          <div>
            <div className="wc-stat-label">Humidity</div>
            <div className="wc-stat-value"><span className="mono">94</span>%</div>
          </div>
        </div>
        <div className="wc-stat">
          <div className="wc-stat-icon"><IconCloudRain size={14} /></div>
          <div>
            <div className="wc-stat-label">Rain rate</div>
            <div className="wc-stat-value"><span className="mono">9.2</span> mm/h</div>
          </div>
        </div>
        <div className="wc-stat">
          <div className="wc-stat-icon"><IconThermometer size={14} /></div>
          <div>
            <div className="wc-stat-label">Pressure</div>
            <div className="wc-stat-value"><span className="mono">994</span> hPa</div>
          </div>
        </div>
      </div>

      <div className="wc-forecast">
        <div className="wc-fc-header">
          <span>Precipitation · next 6 hours</span>
          <span className="wc-fc-total"><span className="mono">16.4</span> mm total</span>
        </div>
        <div className="wc-bars">
          {next6h.map((b, i) => (
            <div className="wc-bar-col" key={i}>
              <div className="wc-bar-track">
                <div
                  className="wc-bar-fill"
                  style={{ height: `${(b.mm / maxMm) * 100}%` }}
                />
              </div>
              <div className="wc-bar-mm mono">{b.mm}</div>
              <div className="wc-bar-h mono">{b.h}:00</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const MapPanel = ({ pins, hoveredPinId, setHoveredPinId }) => (
  <div className="map-panel">
    <div className="map-header">
      <div>
        <div className="card-title">Live map · Bergen region</div>
        <div className="card-sub">7 active markers · updated <span className="mono">2 min ago</span></div>
      </div>
      <div className="map-filters">
        <button className="chip chip-on"><span className="chip-dot" style={{ background: "#DC2626" }} />Incidents <span className="chip-count">4</span></button>
        <button className="chip chip-on"><span className="chip-dot" style={{ background: "#E85D2C" }} />Tunnels <span className="chip-count">2</span></button>
        <button className="chip chip-on"><span className="chip-dot" style={{ background: "#CA8A04" }} />Construction <span className="chip-count">2</span></button>
      </div>
    </div>
    <BergenMap
      incidents={pins}
      hoveredPinId={hoveredPinId}
      onPinHover={setHoveredPinId}
    />
  </div>
);

const ChartPanel = () => {
  const [hoverIdx, setHoverIdx] = useState(4);
  return (
    <div className="card chart-card">
      <div className="card-head">
        <div>
          <div className="card-title">Weather vs Traffic — last 7 days</div>
          <div className="card-sub">Daily incident count overlaid with precipitation totals · Pearson r = <span className="mono">0.84</span></div>
        </div>
        <div className="legend">
          <span className="lg-item"><span className="lg-swatch" style={{ background: "#F4A57E" }} />Incidents</span>
          <span className="lg-item"><span className="lg-line" />Precipitation (mm)</span>
        </div>
      </div>
      <CorrelationChart data={CHART_DATA} hoverIdx={hoverIdx} setHoverIdx={setHoverIdx} />
    </div>
  );
};

const IncidentsTable = () => {
  const [sortBy, setSortBy] = useState("severity");
  const sorted = useMemo(() => {
    const order = { High: 0, Medium: 1, Low: 2 };
    return [...INCIDENTS].sort((a, b) => {
      if (sortBy === "severity") return order[a.severity] - order[b.severity];
      if (sortBy === "started") return a.started.localeCompare(b.started);
      return 0;
    });
  }, [sortBy]);

  return (
    <div className="card table-card">
      <div className="card-head">
        <div>
          <div className="card-title">Active incidents</div>
          <div className="card-sub"><span className="mono">6</span> events · sorted by severity</div>
        </div>
        <div className="table-tools">
          <div className="search">
            <IconSearch size={14} />
            <input placeholder="Search location, route…" />
          </div>
          <button className="btn-ghost"><IconFilter size={13} /> Filter</button>
          <button className="btn-ghost"><IconDownload size={13} /> Export CSV</button>
        </div>
      </div>

      <table className="incidents-table">
        <thead>
          <tr>
            <th onClick={() => setSortBy("location")}>Location <IconChevronDown size={12} /></th>
            <th>Type</th>
            <th onClick={() => setSortBy("severity")}>Severity <IconChevronDown size={12} /></th>
            <th onClick={() => setSortBy("started")}>Started <IconChevronDown size={12} /></th>
            <th>Weather at start</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((row) => (
            <tr key={row.id}>
              <td>
                <div className="loc-cell">
                  <div className="route-tag">{row.route}</div>
                  <div>
                    <div className="loc-name">{row.location}</div>
                    <div className="loc-dur mono">duration {row.duration}</div>
                  </div>
                </div>
              </td>
              <td>
                <span className="type-cell">
                  <span className="type-icon"><TypeIcon kind={row.typeIcon} /></span>
                  {row.type}
                </span>
              </td>
              <td><SeverityBadge level={row.severity} /></td>
              <td className="mono cell-mono">{row.started}</td>
              <td>
                <span className="weather-cell">
                  <span className="weather-cell-icon"><TypeIcon kind={row.weatherIcon} size={13} /></span>
                  {row.weather}
                </span>
              </td>
              <td><StatusBadge status={row.status} /></td>
              <td><button className="row-action">View →</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// ─── Tweaks defaults & app ──────────────────────────────────────────────────

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentColor": "#E85D2C",
  "showAIBorder": true,
  "compactKPI": false,
  "tableDensity": "comfortable"
}/*EDITMODE-END*/;

const App = () => {
  const [lang, setLang] = useState("EN");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [generating, setGenerating] = useState(false);
  const [hoveredPinId, setHoveredPinId] = useState(null);
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply accent color globally
  useEffect(() => {
    document.documentElement.style.setProperty("--accent", tweaks.accentColor);
  }, [tweaks.accentColor]);

  useEffect(() => {
    document.body.dataset.density = tweaks.tableDensity;
    document.body.dataset.aiBorder = tweaks.showAIBorder ? "1" : "0";
    document.body.dataset.kpiCompact = tweaks.compactKPI ? "1" : "0";
  }, [tweaks]);

  const handleGenerate = () => {
    setGenerating(true);
    setTimeout(() => setGenerating(false), 2200);
  };

  return (
    <div className="app">
      <TopNav lang={lang} setLang={setLang} activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="main">
        <PageHeader onGenerate={handleGenerate} generating={generating} />
        <KPIRow />
        <AIReport generating={generating} />

        <div className="row-2col">
          <WeatherCard />
          <MapPanel pins={MAP_PINS} hoveredPinId={hoveredPinId} setHoveredPinId={setHoveredPinId} />
        </div>

        <ChartPanel />
        <IncidentsTable />

        <footer className="foot">
          <span>weather_traffic v2.4.1 · Bergen pilot</span>
          <span>Data: MET Norway (CC BY 4.0) · Statens vegvesen Datex II</span>
        </footer>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Brand">
          <TweakColor label="Accent color" value={tweaks.accentColor} onChange={(v) => setTweak("accentColor", v)} />
        </TweakSection>
        <TweakSection title="AI report">
          <TweakToggle label="Show orange left border" value={tweaks.showAIBorder} onChange={(v) => setTweak("showAIBorder", v)} />
        </TweakSection>
        <TweakSection title="Layout">
          <TweakToggle label="Compact KPI tiles" value={tweaks.compactKPI} onChange={(v) => setTweak("compactKPI", v)} />
          <TweakRadio
            label="Table density"
            value={tweaks.tableDensity}
            onChange={(v) => setTweak("tableDensity", v)}
            options={[
              { value: "comfortable", label: "Comfortable" },
              { value: "compact", label: "Compact" },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
