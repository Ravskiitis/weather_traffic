// 7-day combined chart: bars (incident count) + line (precipitation mm)

const CorrelationChart = ({ data, hoverIdx, setHoverIdx }) => {
  const W = 1100, H = 280;
  const padL = 48, padR = 48, padT = 24, padB = 40;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;

  const maxIncidents = Math.max(...data.map((d) => d.incidents), 8);
  const maxPrecip = Math.max(...data.map((d) => d.precip), 20);

  const incidentScale = (n) => innerH - (n / maxIncidents) * innerH;
  const precipScale = (n) => innerH - (n / maxPrecip) * innerH;

  const barW = innerW / data.length * 0.55;
  const slotW = innerW / data.length;

  const linePath = data
    .map((d, i) => {
      const x = padL + slotW * i + slotW / 2;
      const y = padT + precipScale(d.precip);
      return `${i === 0 ? "M" : "L"} ${x},${y}`;
    })
    .join(" ");

  const areaPath = linePath +
    ` L ${padL + slotW * (data.length - 1) + slotW / 2},${padT + innerH}` +
    ` L ${padL + slotW / 2},${padT + innerH} Z`;

  // Y-axis ticks
  const yTicksLeft = [0, 0.25, 0.5, 0.75, 1].map((p) => Math.round(maxIncidents * p));
  const yTicksRight = [0, 0.25, 0.5, 0.75, 1].map((p) => Math.round(maxPrecip * p));

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="cc-svg" preserveAspectRatio="xMidYMid meet">
      <defs>
        <linearGradient id="cc-area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Grid + left ticks */}
      <g fontFamily="JetBrains Mono, monospace" fontSize="10" fill="#94A3B8">
        {yTicksLeft.map((v, i) => {
          const y = padT + innerH - (i / (yTicksLeft.length - 1)) * innerH;
          return (
            <g key={i}>
              <line x1={padL} y1={y} x2={padL + innerW} y2={y} stroke="#EEF0F4" strokeWidth="1" />
              <text x={padL - 8} y={y + 3} textAnchor="end">{v}</text>
            </g>
          );
        })}
        {/* Right ticks */}
        {yTicksRight.map((v, i) => {
          const y = padT + innerH - (i / (yTicksRight.length - 1)) * innerH;
          return (
            <text key={i} x={padL + innerW + 8} y={y + 3} fill="#3B82F6">{v}</text>
          );
        })}
      </g>

      {/* Axis labels */}
      <text x={padL - 32} y={padT - 8} fontFamily="Inter" fontSize="10" fill="#475569" fontWeight="600">Incidents</text>
      <text x={padL + innerW + 8} y={padT - 8} fontFamily="Inter" fontSize="10" fill="#3B82F6" fontWeight="600">Precip (mm)</text>

      {/* Bars */}
      {data.map((d, i) => {
        const x = padL + slotW * i + (slotW - barW) / 2;
        const y = padT + incidentScale(d.incidents);
        const h = innerH - incidentScale(d.incidents);
        const isHover = hoverIdx === i;
        return (
          <g key={i}>
            <rect
              x={padL + slotW * i}
              y={padT}
              width={slotW}
              height={innerH}
              fill="transparent"
              onMouseEnter={() => setHoverIdx(i)}
              onMouseLeave={() => setHoverIdx(null)}
              style={{ cursor: "pointer" }}
            />
            <rect x={x} y={y} width={barW} height={h} rx="3" fill={isHover ? "#E85D2C" : "#F4A57E"} />
            {isHover && (
              <rect x={x} y={y - 1} width={barW} height={h + 1} rx="3" fill="none" stroke="#E85D2C" strokeWidth="1.5" />
            )}
          </g>
        );
      })}

      {/* Precip area + line */}
      <path d={areaPath} fill="url(#cc-area)" />
      <path d={linePath} fill="none" stroke="#3B82F6" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round" />

      {/* Line points */}
      {data.map((d, i) => {
        const x = padL + slotW * i + slotW / 2;
        const y = padT + precipScale(d.precip);
        const isHover = hoverIdx === i;
        return (
          <circle
            key={i}
            cx={x}
            cy={y}
            r={isHover ? 5 : 3.5}
            fill="#FFFFFF"
            stroke="#3B82F6"
            strokeWidth="2"
          />
        );
      })}

      {/* X-axis labels */}
      <g fontFamily="Inter" fontSize="11" fill="#475569">
        {data.map((d, i) => {
          const x = padL + slotW * i + slotW / 2;
          return (
            <g key={i}>
              <text x={x} y={padT + innerH + 18} textAnchor="middle" fontWeight={hoverIdx === i ? 700 : 500} fill={hoverIdx === i ? "#0F172A" : "#475569"}>{d.day}</text>
              <text x={x} y={padT + innerH + 32} textAnchor="middle" fontSize="9" fill="#94A3B8" fontFamily="JetBrains Mono">{d.date}</text>
            </g>
          );
        })}
      </g>

      {/* Tooltip */}
      {hoverIdx !== null && (() => {
        const d = data[hoverIdx];
        const x = padL + slotW * hoverIdx + slotW / 2;
        const tx = Math.min(Math.max(x - 90, padL), padL + innerW - 180);
        const ty = padT + 8;
        return (
          <g transform={`translate(${tx},${ty})`}>
            <rect width="180" height="92" rx="8" fill="#0F172A" />
            <text x="14" y="20" fill="#FFFFFF" fontFamily="Inter" fontSize="11" fontWeight="700">{d.day}, {d.date}</text>
            <line x1="14" y1="28" x2="166" y2="28" stroke="#1E293B" />
            <g transform="translate(14,46)">
              <rect width="8" height="8" rx="2" fill="#F4A57E" />
              <text x="14" y="8" fill="#CBD5E1" fontSize="10" fontFamily="Inter">Incidents</text>
              <text x="166" y="8" textAnchor="end" fill="#FFFFFF" fontSize="11" fontFamily="JetBrains Mono" fontWeight="700">{d.incidents}</text>
            </g>
            <g transform="translate(14,68)">
              <rect width="8" height="8" rx="2" fill="#3B82F6" />
              <text x="14" y="8" fill="#CBD5E1" fontSize="10" fontFamily="Inter">Precipitation</text>
              <text x="166" y="8" textAnchor="end" fill="#FFFFFF" fontSize="11" fontFamily="JetBrains Mono" fontWeight="700">{d.precip} mm</text>
            </g>
          </g>
        );
      })()}
    </svg>
  );
};

window.CorrelationChart = CorrelationChart;
